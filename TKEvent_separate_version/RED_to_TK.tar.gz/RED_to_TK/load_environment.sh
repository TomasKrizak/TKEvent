#!/bin/bash 

source /sps/nemo/sw/config/supernemo_profile_1.bash

load_supernemo_setup_new

export RED_PATH=/sps/nemo/snemo/snemo_data/raw_data/v1/RED/delta-tdc-10us/
